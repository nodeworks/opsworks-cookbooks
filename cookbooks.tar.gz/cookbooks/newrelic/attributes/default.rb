default[:newrelic][:key] = ''
