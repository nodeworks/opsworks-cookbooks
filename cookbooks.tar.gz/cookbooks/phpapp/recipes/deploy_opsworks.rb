app = search(:aws_opsworks_app).first
rds_db_instance = search(:aws_opsworks_rds_db_instance).first
rds_db_name = search(:aws_opsworks_app).first[:data_sources].first[:database_name]
app_path = "/var/app"

# deploy git repo from opsworks app
application app_path do
  git app_path do
    repository app['app_source']['url']
    deploy_key app['app_source']['ssh_key']
    group 'www-data'
    user 'www-data'
  end
end

template '/var/app/creds.json' do
  source 'creds.erb'
  mode '0777'
  variables(
    :username => rds_db_instance[:db_user],
    :password => rds_db_instance[:db_password],
    :database => rds_db_name,
    :host => rds_db_instance[:address]
  )
end

execute "chown-data-www" do
  command "chown -R www-data:www-data /var/app"
  user "root"
  action :nothing
end

